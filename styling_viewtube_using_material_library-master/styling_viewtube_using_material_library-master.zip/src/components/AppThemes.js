import { createTheme, responsiveFontSizes } from '@material-ui/core/styles';


// Add custom theme object here
const viewTubeTheme = null
export {
  viewTubeTheme,
}
